package com.example.appmakananbatak;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

public class Splashscreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);

        Button btn1=(Button)findViewById(R.id.btnCek);
        final ProgressBar progressbr=(ProgressBar)findViewById(R.id.progress);
        progressbr.setVisibility(View.GONE);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressbr.setVisibility(View.VISIBLE);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent2=new Intent(Splashscreen  .this, ListMakanan.class);
                        startActivity(intent2);
                        finish();
                    }
                }, 3000);

            }
        });
    }
}
