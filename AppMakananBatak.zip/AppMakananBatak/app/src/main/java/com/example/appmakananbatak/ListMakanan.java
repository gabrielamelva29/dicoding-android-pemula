package com.example.appmakananbatak;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ListMakanan extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<String> Nama;
    private ArrayList<Integer> Gambar;
    private ArrayList<String> Harga;

    private String[] NamaMakanan = {
            "Arsik",
            "Naniura",
            "Natinombur",
            "Napinadar",
            "Babi Panggang",
            "Saksang",
            "Tanggo-tanggo",
            "Dali Ni Horbo",
            "Daun Ubi Tumbuk",
            "Daun Ubi Jantung Pisang"
    };


    private String[] hargaMakanan={
            "Rp. 50.000 /porsi",
            "Rp. 75.000 /porsi",
            "Rp. 65.000 /porsi",
            "Rp. 80.000 /porsi",
            "Rp. 50.000 /porsi",
            "Rp. 40.000 /porsi",
            "Rp. 45.000 /porsi",
            "Rp. 30.000 /porsi",
            "Rp. 10.000 /porsi",
            "Rp. 15.000 /porsi",
    };

    private int[] GambarMakanan = {
            R.drawable.arsik,
            R.drawable.naniura,
            R.drawable.natinombur,
            R.drawable.napinadar,
            R.drawable.babi_panggang,
            R.drawable.saksang,
            R.drawable.tango_tango,
            R.drawable.dalini_horbo,
            R.drawable.daunubi_tumbuk,
            R.drawable.daunubi_jantungpisang
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Nama = new ArrayList<>();
        Gambar = new ArrayList<>();
        Harga = new ArrayList<>();
        recyclerView = findViewById(R.id.recycler);
        DaftarItem();

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        adapter = new RecyclerViewAdapter(Nama, Gambar,Harga);

        recyclerView.setAdapter(adapter);
    }

    private void DaftarItem(){
        for (int w=0; w<NamaMakanan.length; w++){
            Gambar.add(GambarMakanan[w]);
            Nama.add(NamaMakanan[w]);
            Harga.add(hargaMakanan[w]);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {

        getMenuInflater().inflate(R.menu.action_about,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.profile:
                Intent about=new Intent(getApplicationContext(), About.class);
                startActivity(about);
                return true;
        }
        return false;
    }
}
