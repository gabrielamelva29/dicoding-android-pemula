package com.example.appmakananbatak;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{

    private ArrayList<String> arrayList;
    private ArrayList<Integer> gambarList;
    private ArrayList<String> hargaList;


    RecyclerViewAdapter(ArrayList<String> arrayList, ArrayList<Integer> gambarList, ArrayList<String> hargaList){
        this.arrayList = arrayList;
        this.gambarList = gambarList;
        this.hargaList  = hargaList;
    }


    class ViewHolder extends RecyclerView.ViewHolder{

        private TextView NamaMakanan, HargaMakanan;
        private ImageView Makanan;
        private RelativeLayout ItemList;
        private Context context;

        ViewHolder(View itemView) {
            super(itemView);

            context = itemView.getContext();

            NamaMakanan = itemView.findViewById(R.id.namamakanan);
            HargaMakanan = itemView.findViewById(R.id.harga);
            Makanan = itemView.findViewById(R.id.makanan);
            ItemList = itemView.findViewById(R.id.item_list);
            ItemList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent();
                    switch (getAdapterPosition()){
                        case 0 :
                            intent = new Intent(context, ArsikActivity.class);
                            break;
                        case 1 :
                            intent = new Intent(context, NaniuraActivity.class);
                            break;
                        case 2 :
                            intent = new Intent(context, NatinomburActivity.class);
                            break;
                        case 3:
                            intent = new Intent(context, NapinadarActivity.class);
                            break;
                        case 4:
                            intent = new Intent(context, PanggangActivity.class);
                            break;
                        case 5 :
                            intent = new Intent(context, SaksangActivity.class);
                            break;
                        case 6 :
                            intent = new Intent(context, TangoActivity.class);
                            break;
                        case 7 :
                            intent = new Intent(context, DaliniActivity.class);
                            break;
                        case 8 :
                            intent = new Intent(context, UbiTumbukActivity.class);
                            break;
                        case 9 :
                            intent = new Intent(context, JantungPisangActivity.class);
                            break;
                    }
                    context.startActivity(intent);
                }
            });
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View V = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_design, parent, false);
        ViewHolder VH = new ViewHolder(V);
        return VH;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        final String Nama = arrayList.get(position);
        final String Harga = hargaList.get(position);
        holder.NamaMakanan.setText(Nama);
        holder.HargaMakanan.setText(Harga);
        holder.Makanan.setImageResource(gambarList.get(position));
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

}